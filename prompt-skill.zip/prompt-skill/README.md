# Skill /prompt (v2.7)

Reescreve um pedido escrito às pressas como um prompt estruturado para o Claude Code: objetivo, contexto, insumos, escopo, restrições, critério de pronto, autonomia e formato de saída, conforme o tipo de tarefa (9 tipos). Não executa nada antes de você aprovar.

## Instalar
```bash
mkdir -p ~/.claude/skills/prompt
cp prompt/SKILL.md ~/.claude/skills/prompt/SKILL.md
```
Uso: `/prompt <o que você quer pedir>`. A skill roda em effort medium (cabeçalho `effort: medium`), a condição em que foi avaliada; a execução depois do "sim" segue o seu nível de esforço.

## Comportamentos principais
- Lê no máximo 3 arquivos de contexto e não altera nada antes da aprovação.
- Assume o padrão razoável e marca a dúvida em Suposições com "confirme:"; pergunta sempre antes de apagar ou sobrescrever dados ou migrar banco.
- Não inventa requisitos, motivos nem convenções: o que não está no pedido nem no projeto vai para Suposições.
- Troca mecânica (renomear, trocar um import) é tarefa comum, sem plan mode nem esforço alto.

Avaliação: 15/15 nos casos de regressão, validação com 3 repetições sem requisito inventado e correção cega dupla, e sessão longa real (17/11/2026).
